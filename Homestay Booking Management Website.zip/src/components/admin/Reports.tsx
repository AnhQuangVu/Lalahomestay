import { useState, useEffect } from 'react';
import { 
  Download, 
  Calendar
} from 'lucide-react';
import { format, subDays } from 'date-fns';
import { vi } from 'date-fns/locale';
import { projectId, publicAnonKey } from '../../utils/supabase/info';
import OverviewReport from './reports/OverviewReport';
import RevenueReport from './reports/RevenueReport';
import BookingsReport from './reports/BookingsReport';
import RoomsReport from './reports/RoomsReport';
import CustomersReport from './reports/CustomersReport';

interface ReportData {
  // Tổng quan
  totalBookings: number;
  totalRevenue: number;
  totalDeposit: number;
  totalCustomers: number;
  newCustomers: number;
  
  // Phòng
  totalRooms: number;
  occupiedRooms: number;
  availableRooms: number;
  occupancyRate: number;
  totalNights: number;
  
  // Đặt phòng
  confirmedBookings: number;
  cancelledBookings: number;
  checkedInBookings: number;
  checkedOutBookings: number;
  cancelRate: number;
  
  // Doanh thu
  averageBookingValue: number;
  averageNightlyRate: number;
  growthRate: number;
  
  // Chi tiết theo thời gian
  dailyRevenue: Array<{ date: string; revenue: number; bookings: number; }>;
  
  // Top phòng
  topRooms: Array<{ name: string; bookings: number; revenue: number; }>;
  
  // Nguồn đặt phòng
  bookingSources: Array<{ source: string; count: number; }>;
  
  // Trạng thái đặt phòng
  bookingStatus: Array<{ status: string; count: number; }>;
}

export default function Reports() {
  const [reportType, setReportType] = useState('overview');
  const [startDate, setStartDate] = useState(format(subDays(new Date(), 30), 'yyyy-MM-dd'));
  const [endDate, setEndDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [reportData, setReportData] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchReportData();
  }, [startDate, endDate]);

  const fetchReportData = async () => {
    setLoading(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-faeb1932/admin/reports?start_date=${startDate}&end_date=${endDate}`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );
      
      const result = await response.json();
      if (result.success) {
        setReportData(result.data);
      }
    } catch (error) {
      console.error('Error fetching report data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async (format: 'excel' | 'pdf') => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-faeb1932/admin/reports/export?format=${format}&start_date=${startDate}&end_date=${endDate}`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `bao-cao-${format}-${startDate}-${endDate}.${format === 'excel' ? 'xlsx' : 'pdf'}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }
    } catch (error) {
      console.error('Export error:', error);
      alert('Lỗi khi xuất báo cáo. Vui lòng thử lại.');
    }
  };

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString('vi-VN') + 'đ';
  };

  const renderReport = () => {
    if (!reportData) return null;

    switch (reportType) {
      case 'overview':
        return <OverviewReport reportData={reportData} formatCurrency={formatCurrency} />;
      case 'revenue':
        return <RevenueReport reportData={reportData} formatCurrency={formatCurrency} />;
      case 'bookings':
        return <BookingsReport reportData={reportData} formatCurrency={formatCurrency} />;
      case 'rooms':
        return <RoomsReport reportData={reportData} formatCurrency={formatCurrency} />;
      case 'customers':
        return <CustomersReport reportData={reportData} formatCurrency={formatCurrency} />;
      default:
        return <OverviewReport reportData={reportData} formatCurrency={formatCurrency} />;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Đang tải dữ liệu báo cáo...</p>
        </div>
      </div>
    );
  }

  if (!reportData) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <p className="text-gray-600">Không có dữ liệu báo cáo</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-gray-900">Báo cáo - Thống kê</h1>
        
        {/* Export Buttons */}
        <div className="flex space-x-3">
          <button
            onClick={() => handleExport('excel')}
            className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
          >
            <Download className="w-5 h-5" />
            <span>Xuất Excel</span>
          </button>
          <button
            onClick={() => handleExport('pdf')}
            className="flex items-center space-x-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
          >
            <Download className="w-5 h-5" />
            <span>Xuất PDF</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-gray-700 mb-2">Loại báo cáo</label>
            <select
              value={reportType}
              onChange={(e) => setReportType(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
            >
              <option value="overview">Tổng quan</option>
              <option value="revenue">Doanh thu</option>
              <option value="bookings">Đặt phòng</option>
              <option value="rooms">Phòng</option>
              <option value="customers">Khách hàng</option>
            </select>
          </div>

          <div>
            <label className="block text-gray-700 mb-2">
              <Calendar className="w-4 h-4 inline mr-1" />
              Từ ngày
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
            />
          </div>

          <div>
            <label className="block text-gray-700 mb-2">
              <Calendar className="w-4 h-4 inline mr-1" />
              Đến ngày
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
            />
          </div>

          <div className="flex items-end">
            <button 
              onClick={fetchReportData}
              className="w-full px-4 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
            >
              Xem báo cáo
            </button>
          </div>
        </div>
      </div>

      {/* Render the selected report type */}
      {renderReport()}
    </div>
  );
}
