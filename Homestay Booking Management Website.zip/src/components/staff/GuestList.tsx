import { useState, useEffect } from 'react';
import { Search, User, Phone, Mail, Calendar } from 'lucide-react';
import { format } from 'date-fns';
import { vi } from 'date-fns/locale';

interface Guest {
  id: string;
  name: string;
  phone: string;
  email: string;
  room: string;
  checkIn: string;
  checkOut: string;
  status: 'checked-in' | 'checked-out' | 'upcoming';
}

export default function GuestList() {
  const [guests, setGuests] = useState<Guest[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  useEffect(() => {
    // Mock data
    setGuests([
      {
        id: '1',
        name: 'Nguyễn Văn A',
        phone: '0912345678',
        email: 'nguyenvana@email.com',
        room: 'Matcha 102',
        checkIn: new Date().toISOString(),
        checkOut: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString(),
        status: 'checked-in'
      },
      {
        id: '2',
        name: 'Trần Thị B',
        phone: '0987654321',
        email: 'tranthib@email.com',
        room: 'Mellow 201',
        checkIn: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
        checkOut: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
        status: 'checked-out'
      }
    ]);
  }, []);

  const filteredGuests = guests.filter(guest => {
    const matchesSearch = guest.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         guest.phone.includes(searchTerm) ||
                         guest.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || guest.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    const styles: { [key: string]: string } = {
      'checked-in': 'bg-green-100 text-green-800',
      'checked-out': 'bg-gray-100 text-gray-800',
      'upcoming': 'bg-blue-100 text-blue-800'
    };
    const labels: { [key: string]: string } = {
      'checked-in': 'Đang ở',
      'checked-out': 'Đã trả phòng',
      'upcoming': 'Sắp đến'
    };
    return (
      <span className={`px-3 py-1 rounded-full text-sm ${styles[status]}`}>
        {labels[status]}
      </span>
    );
  };

  return (
    <div>
      <h1 className="text-gray-900 mb-6">Khách lưu trú</h1>

      <div className="bg-white rounded-xl shadow-sm p-6">
        {/* Search and Filter */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Tìm theo tên, số điện thoại, email..."
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
            />
          </div>
          
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
          >
            <option value="all">Tất cả trạng thái</option>
            <option value="checked-in">Đang ở</option>
            <option value="upcoming">Sắp đến</option>
            <option value="checked-out">Đã trả phòng</option>
          </select>
        </div>

        {/* Guest List */}
        <div className="space-y-4">
          {filteredGuests.map((guest) => (
            <div key={guest.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="text-gray-900">{guest.name}</h3>
                    {getStatusBadge(guest.status)}
                  </div>
                  <div className="space-y-1 text-sm text-gray-600">
                    <div className="flex items-center space-x-2">
                      <Phone className="w-4 h-4" />
                      <span>{guest.phone}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Mail className="w-4 h-4" />
                      <span>{guest.email}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-gray-900 mb-1">{guest.room}</p>
                  <div className="text-sm text-gray-600">
                    <p>{format(new Date(guest.checkIn), 'dd/MM/yyyy HH:mm', { locale: vi })}</p>
                    <p>{format(new Date(guest.checkOut), 'dd/MM/yyyy HH:mm', { locale: vi })}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredGuests.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            Không tìm thấy khách hàng nào
          </div>
        )}
      </div>
    </div>
  );
}
