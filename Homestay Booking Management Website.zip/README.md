
  # Homestay Booking Management Website

  This is a code bundle for Homestay Booking Management Website. The original project is available at https://www.figma.com/design/TYQyqCS21FHN0QNjSr70CI/Homestay-Booking-Management-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  